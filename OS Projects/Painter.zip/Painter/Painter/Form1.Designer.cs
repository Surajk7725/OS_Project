﻿namespace Painter
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            BtnClear = new Button();
            BtnSave = new Button();
            BtnEllipse = new Button();
            BtnLine = new Button();
            BtnRectangle = new Button();
            BtnPaint = new Button();
            BtnColor = new Button();
            BtnEraser = new Button();
            BtnPencil = new Button();
            Pic = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Pic).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Controls.Add(BtnClear);
            panel1.Controls.Add(BtnSave);
            panel1.Controls.Add(BtnEllipse);
            panel1.Controls.Add(BtnLine);
            panel1.Controls.Add(BtnRectangle);
            panel1.Controls.Add(BtnPaint);
            panel1.Controls.Add(BtnColor);
            panel1.Controls.Add(BtnEraser);
            panel1.Controls.Add(BtnPencil);
            panel1.Location = new Point(3, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(660, 65);
            panel1.TabIndex = 0;
            // 
            // BtnClear
            // 
            BtnClear.Cursor = Cursors.Hand;
            BtnClear.FlatAppearance.MouseDownBackColor = Color.Lime;
            BtnClear.FlatAppearance.MouseOverBackColor = Color.Purple;
            BtnClear.FlatStyle = FlatStyle.Flat;
            BtnClear.ForeColor = Color.White;
            BtnClear.Location = new Point(538, 35);
            BtnClear.Name = "BtnClear";
            BtnClear.Size = new Size(70, 30);
            BtnClear.TabIndex = 5;
            BtnClear.Tag = "BtnClear";
            BtnClear.Text = "Clear";
            BtnClear.UseVisualStyleBackColor = true;
            BtnClear.Click += button9_Click;
            BtnClear.MouseClick += button9_MouseClick;
            BtnClear.MouseDown += button1_MouseDown;
            BtnClear.MouseMove += button1_MouseMove;
            BtnClear.MouseUp += button1_MouseUp;
            // 
            // BtnSave
            // 
            BtnSave.Cursor = Cursors.Hand;
            BtnSave.FlatAppearance.MouseDownBackColor = Color.Lime;
            BtnSave.FlatAppearance.MouseOverBackColor = Color.Purple;
            BtnSave.FlatStyle = FlatStyle.Flat;
            BtnSave.ForeColor = Color.White;
            BtnSave.Location = new Point(589, 0);
            BtnSave.Name = "BtnSave";
            BtnSave.Size = new Size(71, 35);
            BtnSave.TabIndex = 4;
            BtnSave.Tag = "BtnSave";
            BtnSave.Text = "Save";
            BtnSave.UseVisualStyleBackColor = true;
            BtnSave.Click += button8_Click;
            BtnSave.MouseDown += button1_MouseDown;
            BtnSave.MouseMove += button1_MouseMove;
            BtnSave.MouseUp += button1_MouseUp;
            // 
            // BtnEllipse
            // 
            BtnEllipse.BackColor = Color.White;
            BtnEllipse.BackgroundImage = Properties.Resources.eclipse;
            BtnEllipse.BackgroundImageLayout = ImageLayout.Zoom;
            BtnEllipse.Cursor = Cursors.Hand;
            BtnEllipse.FlatAppearance.MouseDownBackColor = Color.Lime;
            BtnEllipse.FlatAppearance.MouseOverBackColor = Color.Purple;
            BtnEllipse.FlatStyle = FlatStyle.Flat;
            BtnEllipse.ForeColor = Color.White;
            BtnEllipse.Location = new Point(232, 11);
            BtnEllipse.Name = "BtnEllipse";
            BtnEllipse.Size = new Size(71, 50);
            BtnEllipse.TabIndex = 0;
            BtnEllipse.Tag = "BtnEllipse";
            BtnEllipse.UseVisualStyleBackColor = false;
            BtnEllipse.Click += button4_Click;
            BtnEllipse.MouseDown += button1_MouseDown;
            BtnEllipse.MouseMove += button1_MouseMove;
            BtnEllipse.MouseUp += button1_MouseUp;
            // 
            // BtnLine
            // 
            BtnLine.BackColor = Color.White;
            BtnLine.BackgroundImage = Properties.Resources.Line;
            BtnLine.BackgroundImageLayout = ImageLayout.Zoom;
            BtnLine.Cursor = Cursors.Hand;
            BtnLine.FlatAppearance.MouseDownBackColor = Color.Lime;
            BtnLine.FlatAppearance.MouseOverBackColor = Color.Purple;
            BtnLine.FlatStyle = FlatStyle.Flat;
            BtnLine.ForeColor = Color.White;
            BtnLine.Location = new Point(461, 11);
            BtnLine.Name = "BtnLine";
            BtnLine.Size = new Size(71, 50);
            BtnLine.TabIndex = 3;
            BtnLine.Tag = "BtnLine";
            BtnLine.UseVisualStyleBackColor = false;
            BtnLine.Click += button7_Click;
            BtnLine.MouseDown += button1_MouseDown;
            BtnLine.MouseMove += button1_MouseMove;
            BtnLine.MouseUp += button1_MouseUp;
            // 
            // BtnRectangle
            // 
            BtnRectangle.BackgroundImage = Properties.Resources.rectangle;
            BtnRectangle.BackgroundImageLayout = ImageLayout.Zoom;
            BtnRectangle.Cursor = Cursors.Hand;
            BtnRectangle.FlatAppearance.MouseDownBackColor = Color.Lime;
            BtnRectangle.FlatAppearance.MouseOverBackColor = Color.Purple;
            BtnRectangle.FlatStyle = FlatStyle.Flat;
            BtnRectangle.ForeColor = Color.White;
            BtnRectangle.Location = new Point(384, 11);
            BtnRectangle.Name = "BtnRectangle";
            BtnRectangle.Size = new Size(71, 50);
            BtnRectangle.TabIndex = 2;
            BtnRectangle.Tag = "BtnRectangle";
            BtnRectangle.UseVisualStyleBackColor = true;
            BtnRectangle.Click += button6_Click;
            BtnRectangle.MouseDown += button1_MouseDown;
            BtnRectangle.MouseMove += button1_MouseMove;
            BtnRectangle.MouseUp += button1_MouseUp;
            // 
            // BtnPaint
            // 
            BtnPaint.BackgroundImage = Properties.Resources.paint;
            BtnPaint.BackgroundImageLayout = ImageLayout.Zoom;
            BtnPaint.Cursor = Cursors.Hand;
            BtnPaint.FlatAppearance.MouseDownBackColor = Color.Lime;
            BtnPaint.FlatAppearance.MouseOverBackColor = Color.Purple;
            BtnPaint.FlatStyle = FlatStyle.Flat;
            BtnPaint.ForeColor = Color.White;
            BtnPaint.Location = new Point(307, 11);
            BtnPaint.Name = "BtnPaint";
            BtnPaint.Size = new Size(71, 50);
            BtnPaint.TabIndex = 1;
            BtnPaint.Tag = "BtnPaint";
            BtnPaint.UseVisualStyleBackColor = true;
            BtnPaint.Click += button5_Click;
            BtnPaint.MouseDown += button1_MouseDown;
            BtnPaint.MouseMove += button1_MouseMove;
            BtnPaint.MouseUp += button1_MouseUp;
            // 
            // BtnColor
            // 
            BtnColor.BackgroundImage = Properties.Resources.colors;
            BtnColor.BackgroundImageLayout = ImageLayout.Zoom;
            BtnColor.Cursor = Cursors.Hand;
            BtnColor.FlatAppearance.MouseDownBackColor = Color.Lime;
            BtnColor.FlatAppearance.MouseOverBackColor = Color.Purple;
            BtnColor.FlatStyle = FlatStyle.Flat;
            BtnColor.ForeColor = Color.White;
            BtnColor.Location = new Point(155, 12);
            BtnColor.Name = "BtnColor";
            BtnColor.Size = new Size(71, 49);
            BtnColor.TabIndex = 1;
            BtnColor.Tag = "BtnColor";
            BtnColor.UseVisualStyleBackColor = true;
            BtnColor.Click += button3_Click;
            BtnColor.MouseDown += button1_MouseDown;
            BtnColor.MouseMove += button1_MouseMove;
            BtnColor.MouseUp += button1_MouseUp;
            // 
            // BtnEraser
            // 
            BtnEraser.BackgroundImage = Properties.Resources.erarser;
            BtnEraser.BackgroundImageLayout = ImageLayout.Zoom;
            BtnEraser.Cursor = Cursors.Hand;
            BtnEraser.FlatAppearance.MouseDownBackColor = Color.Lime;
            BtnEraser.FlatAppearance.MouseOverBackColor = Color.Purple;
            BtnEraser.FlatStyle = FlatStyle.Flat;
            BtnEraser.ForeColor = Color.White;
            BtnEraser.Location = new Point(78, 12);
            BtnEraser.Name = "BtnEraser";
            BtnEraser.Size = new Size(71, 50);
            BtnEraser.TabIndex = 1;
            BtnEraser.Tag = "BtnEraser";
            BtnEraser.UseVisualStyleBackColor = true;
            BtnEraser.Click += button2_Click;
            BtnEraser.MouseDown += button1_MouseDown;
            BtnEraser.MouseMove += button1_MouseMove;
            BtnEraser.MouseUp += button1_MouseUp;
            // 
            // BtnPencil
            // 
            BtnPencil.BackgroundImage = Properties.Resources.download;
            BtnPencil.BackgroundImageLayout = ImageLayout.Zoom;
            BtnPencil.Cursor = Cursors.Hand;
            BtnPencil.FlatAppearance.MouseDownBackColor = Color.Lime;
            BtnPencil.FlatAppearance.MouseOverBackColor = Color.Purple;
            BtnPencil.FlatStyle = FlatStyle.Flat;
            BtnPencil.ForeColor = Color.White;
            BtnPencil.Location = new Point(3, 13);
            BtnPencil.Name = "BtnPencil";
            BtnPencil.Size = new Size(71, 49);
            BtnPencil.TabIndex = 0;
            BtnPencil.Tag = "BtnPencil";
            BtnPencil.UseVisualStyleBackColor = true;
            BtnPencil.Click += button1_Click;
            BtnPencil.MouseDown += button1_MouseDown;
            BtnPencil.MouseMove += button1_MouseMove;
            BtnPencil.MouseUp += button1_MouseUp;
            // 
            // Pic
            // 
            Pic.BackColor = Color.White;
            Pic.Location = new Point(3, 66);
            Pic.Name = "Pic";
            Pic.Size = new Size(660, 270);
            Pic.TabIndex = 1;
            Pic.TabStop = false;
            Pic.Paint += pictureBox1_Paint;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(665, 337);
            Controls.Add(Pic);
            Controls.Add(panel1);
            Name = "Form1";
            Text = "Painter";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)Pic).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button BtnClear;
        private Button BtnSave;
        private Button BtnEllipse;
        private Button BtnLine;
        private Button BtnRectangle;
        private Button BtnPaint;
        private Button BtnColor;
        private Button BtnEraser;
        private Button BtnPencil;
        private PictureBox Pic;
    }
}