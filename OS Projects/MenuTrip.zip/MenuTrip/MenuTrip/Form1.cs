namespace MenuTrip
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void animesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 to = new Form2();
            to.Show();
            this.Hide();
        }

        private void charactersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 to = new Form3();
            to.Show();
            this.Hide();
        }
    }
}