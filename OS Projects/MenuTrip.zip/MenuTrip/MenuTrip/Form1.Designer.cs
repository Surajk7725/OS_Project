﻿namespace MenuTrip
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            homeToolStripMenuItem = new ToolStripMenuItem();
            animesToolStripMenuItem = new ToolStripMenuItem();
            charactersToolStripMenuItem = new ToolStripMenuItem();
            animesToolStripMenuItem1 = new ToolStripMenuItem();
            cOTEToolStripMenuItem = new ToolStripMenuItem();
            demonSlayerToolStripMenuItem = new ToolStripMenuItem();
            lycrosisRecoilToolStripMenuItem = new ToolStripMenuItem();
            charactersToolStripMenuItem1 = new ToolStripMenuItem();
            kiyotakaToolStripMenuItem = new ToolStripMenuItem();
            ayanokojiToolStripMenuItem = new ToolStripMenuItem();
            keiToolStripMenuItem = new ToolStripMenuItem();
            arisuToolStripMenuItem = new ToolStripMenuItem();
            chisatoToolStripMenuItem = new ToolStripMenuItem();
            tanjiroToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { homeToolStripMenuItem, animesToolStripMenuItem1, charactersToolStripMenuItem1 });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // homeToolStripMenuItem
            // 
            homeToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { animesToolStripMenuItem, charactersToolStripMenuItem });
            homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            homeToolStripMenuItem.Size = new Size(52, 20);
            homeToolStripMenuItem.Text = "Home";
            // 
            // animesToolStripMenuItem
            // 
            animesToolStripMenuItem.Name = "animesToolStripMenuItem";
            animesToolStripMenuItem.Size = new Size(180, 22);
            animesToolStripMenuItem.Text = "Animes";
            animesToolStripMenuItem.Click += animesToolStripMenuItem_Click;
            // 
            // charactersToolStripMenuItem
            // 
            charactersToolStripMenuItem.Name = "charactersToolStripMenuItem";
            charactersToolStripMenuItem.Size = new Size(180, 22);
            charactersToolStripMenuItem.Text = "Characters";
            charactersToolStripMenuItem.Click += charactersToolStripMenuItem_Click;
            // 
            // animesToolStripMenuItem1
            // 
            animesToolStripMenuItem1.DropDownItems.AddRange(new ToolStripItem[] { cOTEToolStripMenuItem, demonSlayerToolStripMenuItem, lycrosisRecoilToolStripMenuItem });
            animesToolStripMenuItem1.Name = "animesToolStripMenuItem1";
            animesToolStripMenuItem1.Size = new Size(59, 20);
            animesToolStripMenuItem1.Text = "Animes";
            // 
            // cOTEToolStripMenuItem
            // 
            cOTEToolStripMenuItem.Name = "cOTEToolStripMenuItem";
            cOTEToolStripMenuItem.Size = new Size(150, 22);
            cOTEToolStripMenuItem.Text = "COTE";
            // 
            // demonSlayerToolStripMenuItem
            // 
            demonSlayerToolStripMenuItem.Name = "demonSlayerToolStripMenuItem";
            demonSlayerToolStripMenuItem.Size = new Size(150, 22);
            demonSlayerToolStripMenuItem.Text = "Demon Slayer";
            // 
            // lycrosisRecoilToolStripMenuItem
            // 
            lycrosisRecoilToolStripMenuItem.Name = "lycrosisRecoilToolStripMenuItem";
            lycrosisRecoilToolStripMenuItem.Size = new Size(150, 22);
            lycrosisRecoilToolStripMenuItem.Text = "Lycrosis Recoil";
            // 
            // charactersToolStripMenuItem1
            // 
            charactersToolStripMenuItem1.DropDownItems.AddRange(new ToolStripItem[] { kiyotakaToolStripMenuItem, chisatoToolStripMenuItem, tanjiroToolStripMenuItem });
            charactersToolStripMenuItem1.Name = "charactersToolStripMenuItem1";
            charactersToolStripMenuItem1.Size = new Size(75, 20);
            charactersToolStripMenuItem1.Text = "Characters";
            // 
            // kiyotakaToolStripMenuItem
            // 
            kiyotakaToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { ayanokojiToolStripMenuItem, keiToolStripMenuItem, arisuToolStripMenuItem });
            kiyotakaToolStripMenuItem.Name = "kiyotakaToolStripMenuItem";
            kiyotakaToolStripMenuItem.Size = new Size(119, 22);
            kiyotakaToolStripMenuItem.Text = "Kiyotaka";
            // 
            // ayanokojiToolStripMenuItem
            // 
            ayanokojiToolStripMenuItem.Name = "ayanokojiToolStripMenuItem";
            ayanokojiToolStripMenuItem.Size = new Size(127, 22);
            ayanokojiToolStripMenuItem.Text = "Ayanokoji";
            // 
            // keiToolStripMenuItem
            // 
            keiToolStripMenuItem.Name = "keiToolStripMenuItem";
            keiToolStripMenuItem.Size = new Size(127, 22);
            keiToolStripMenuItem.Text = "Kei";
            // 
            // arisuToolStripMenuItem
            // 
            arisuToolStripMenuItem.Name = "arisuToolStripMenuItem";
            arisuToolStripMenuItem.Size = new Size(127, 22);
            arisuToolStripMenuItem.Text = "Arisu";
            // 
            // chisatoToolStripMenuItem
            // 
            chisatoToolStripMenuItem.Name = "chisatoToolStripMenuItem";
            chisatoToolStripMenuItem.Size = new Size(119, 22);
            chisatoToolStripMenuItem.Text = "Chisato";
            // 
            // tanjiroToolStripMenuItem
            // 
            tanjiroToolStripMenuItem.Name = "tanjiroToolStripMenuItem";
            tanjiroToolStripMenuItem.Size = new Size(119, 22);
            tanjiroToolStripMenuItem.Text = "Tanjiro";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem homeToolStripMenuItem;
        private ToolStripMenuItem animesToolStripMenuItem;
        private ToolStripMenuItem charactersToolStripMenuItem;
        private ToolStripMenuItem animesToolStripMenuItem1;
        private ToolStripMenuItem cOTEToolStripMenuItem;
        private ToolStripMenuItem demonSlayerToolStripMenuItem;
        private ToolStripMenuItem lycrosisRecoilToolStripMenuItem;
        private ToolStripMenuItem charactersToolStripMenuItem1;
        private ToolStripMenuItem kiyotakaToolStripMenuItem;
        private ToolStripMenuItem ayanokojiToolStripMenuItem;
        private ToolStripMenuItem keiToolStripMenuItem;
        private ToolStripMenuItem arisuToolStripMenuItem;
        private ToolStripMenuItem chisatoToolStripMenuItem;
        private ToolStripMenuItem tanjiroToolStripMenuItem;
    }
}