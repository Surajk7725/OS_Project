﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsOS
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void timerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form3().Show();
            this.Hide();
        }

        private void dateAndTimeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form4().Show();
            this.Hide();
        }

        private void webBrowserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form5().Show();
            this.Hide();
        }

        private void calculatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form6().Show();
            this.Hide();

        }

        private void wordPadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form7().Show();
            this.Hide();
        }

        private void painterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form8().Show();
            this.Hide();
        }
    }
}
