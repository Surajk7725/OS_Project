﻿namespace WindowsOS
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            pictureBox1 = new PictureBox();
            appToolStripMenuItem = new ToolStripMenuItem();
            timerToolStripMenuItem = new ToolStripMenuItem();
            dateAndTimeToolStripMenuItem = new ToolStripMenuItem();
            webBrowserToolStripMenuItem = new ToolStripMenuItem();
            calculatorToolStripMenuItem = new ToolStripMenuItem();
            wordPadToolStripMenuItem = new ToolStripMenuItem();
            painterToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { appToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(528, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources._24;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(0, 27);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(528, 258);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // appToolStripMenuItem
            // 
            appToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { timerToolStripMenuItem, dateAndTimeToolStripMenuItem, webBrowserToolStripMenuItem, calculatorToolStripMenuItem, wordPadToolStripMenuItem, painterToolStripMenuItem });
            appToolStripMenuItem.Name = "appToolStripMenuItem";
            appToolStripMenuItem.Size = new Size(41, 20);
            appToolStripMenuItem.Text = "App";
            // 
            // timerToolStripMenuItem
            // 
            timerToolStripMenuItem.Name = "timerToolStripMenuItem";
            timerToolStripMenuItem.Size = new Size(180, 22);
            timerToolStripMenuItem.Text = "Timer";
            timerToolStripMenuItem.Click += timerToolStripMenuItem_Click;
            // 
            // dateAndTimeToolStripMenuItem
            // 
            dateAndTimeToolStripMenuItem.Name = "dateAndTimeToolStripMenuItem";
            dateAndTimeToolStripMenuItem.Size = new Size(180, 22);
            dateAndTimeToolStripMenuItem.Text = "Date And Time";
            dateAndTimeToolStripMenuItem.Click += dateAndTimeToolStripMenuItem_Click;
            // 
            // webBrowserToolStripMenuItem
            // 
            webBrowserToolStripMenuItem.Name = "webBrowserToolStripMenuItem";
            webBrowserToolStripMenuItem.Size = new Size(180, 22);
            webBrowserToolStripMenuItem.Text = "Web Browser";
            webBrowserToolStripMenuItem.Click += webBrowserToolStripMenuItem_Click;
            // 
            // calculatorToolStripMenuItem
            // 
            calculatorToolStripMenuItem.Name = "calculatorToolStripMenuItem";
            calculatorToolStripMenuItem.Size = new Size(180, 22);
            calculatorToolStripMenuItem.Text = "Calculator";
            calculatorToolStripMenuItem.Click += calculatorToolStripMenuItem_Click;
            // 
            // wordPadToolStripMenuItem
            // 
            wordPadToolStripMenuItem.Name = "wordPadToolStripMenuItem";
            wordPadToolStripMenuItem.Size = new Size(180, 22);
            wordPadToolStripMenuItem.Text = "Word Pad";
            wordPadToolStripMenuItem.Click += wordPadToolStripMenuItem_Click;
            // 
            // painterToolStripMenuItem
            // 
            painterToolStripMenuItem.Name = "painterToolStripMenuItem";
            painterToolStripMenuItem.Size = new Size(180, 22);
            painterToolStripMenuItem.Text = "Painter";
            painterToolStripMenuItem.Click += painterToolStripMenuItem_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(528, 281);
            Controls.Add(pictureBox1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form2";
            Text = "Form2";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private PictureBox pictureBox1;
        private ToolStripMenuItem appToolStripMenuItem;
        private ToolStripMenuItem timerToolStripMenuItem;
        private ToolStripMenuItem dateAndTimeToolStripMenuItem;
        private ToolStripMenuItem webBrowserToolStripMenuItem;
        private ToolStripMenuItem calculatorToolStripMenuItem;
        private ToolStripMenuItem wordPadToolStripMenuItem;
        private ToolStripMenuItem painterToolStripMenuItem;
    }
}