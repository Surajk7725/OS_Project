﻿namespace WordPad
{
    partial class frmFind
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnFind = new Button();
            btnCancel = new Button();
            textFindWhat = new Label();
            textBox1 = new TextBox();
            chkMatchCase = new CheckBox();
            groupBox1 = new GroupBox();
            rdoUp = new RadioButton();
            rdoDown = new RadioButton();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // btnFind
            // 
            btnFind.Location = new Point(391, 35);
            btnFind.Name = "btnFind";
            btnFind.Size = new Size(180, 28);
            btnFind.TabIndex = 0;
            btnFind.Text = "Find Next";
            btnFind.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(391, 81);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(180, 32);
            btnCancel.TabIndex = 1;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            // 
            // textFindWhat
            // 
            textFindWhat.AutoSize = true;
            textFindWhat.Location = new Point(41, 41);
            textFindWhat.Name = "textFindWhat";
            textFindWhat.Size = new Size(62, 15);
            textFindWhat.TabIndex = 2;
            textFindWhat.Text = "Find what:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(109, 35);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(276, 27);
            textBox1.TabIndex = 3;
            // 
            // chkMatchCase
            // 
            chkMatchCase.AutoSize = true;
            chkMatchCase.Location = new Point(41, 112);
            chkMatchCase.Name = "chkMatchCase";
            chkMatchCase.Size = new Size(88, 19);
            chkMatchCase.TabIndex = 4;
            chkMatchCase.Text = "Match Case";
            chkMatchCase.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rdoDown);
            groupBox1.Controls.Add(rdoUp);
            groupBox1.Location = new Point(147, 94);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(213, 60);
            groupBox1.TabIndex = 5;
            groupBox1.TabStop = false;
            groupBox1.Text = "Direction";
            // 
            // rdoUp
            // 
            rdoUp.AutoSize = true;
            rdoUp.Location = new Point(16, 28);
            rdoUp.Name = "rdoUp";
            rdoUp.Size = new Size(40, 19);
            rdoUp.TabIndex = 0;
            rdoUp.TabStop = true;
            rdoUp.Text = "Up";
            rdoUp.UseVisualStyleBackColor = true;
            // 
            // rdoDown
            // 
            rdoDown.AutoSize = true;
            rdoDown.Location = new Point(89, 28);
            rdoDown.Name = "rdoDown";
            rdoDown.Size = new Size(56, 19);
            rdoDown.TabIndex = 1;
            rdoDown.TabStop = true;
            rdoDown.Text = "Down";
            rdoDown.UseVisualStyleBackColor = true;
            // 
            // frmFind
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            Controls.Add(chkMatchCase);
            Controls.Add(textBox1);
            Controls.Add(textFindWhat);
            Controls.Add(btnCancel);
            Controls.Add(btnFind);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "frmFind";
            Text = "Find what:";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnFind;
        private Button btnCancel;
        private Label textFindWhat;
        private TextBox textBox1;
        private CheckBox chkMatchCase;
        private GroupBox groupBox1;
        private RadioButton rdoDown;
        private RadioButton rdoUp;
    }
}