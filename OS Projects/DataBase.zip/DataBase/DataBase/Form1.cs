﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.CodeDom;

namespace DataBase
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\suraj\\OneDrive\\Documents\\Details_Anime.mdf;Integrated Security=True;Connect Timeout=30 ");
            conn.Open();
            SqlCommand cmd = new SqlCommand(@"insert into [Table] values(@Id,@Name,@Anime,@Favourite)", conn);
            cmd.Parameters.AddWithValue("@Id", int.Parse(textBox4.Text));
            cmd.Parameters.AddWithValue("@Name", textBox1.Text);
            cmd.Parameters.AddWithValue("@Anime", textBox2.Text);
            cmd.Parameters.AddWithValue("@Favourite", textBox3.Text);
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Data Inserted Successfully...!");

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox5.Text = dateTime1.Value.ToString("dd-MM-yyyy");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\suraj\\OneDrive\\Documents\\Details_Anime.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            SqlCommand cmd = new SqlCommand(@"select * from [Table]", con);
            SqlDataAdapter adapter=new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\suraj\\OneDrive\\Documents\\Details_Anime.mdf;Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand cmd = new SqlCommand(@"delete from [Table] where Id=@Id", conn);
            cmd.Parameters.AddWithValue("@Id",int.Parse(textBox4.Text));
            cmd.ExecuteNonQuery();
            conn.Close();

            MessageBox.Show("Data Deleted Successfully");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox4.Text = " ";
            textBox1.Text = " ";
            textBox2.Text = " ";
            textBox3.Text = " ";
            textBox5.Text= " ";
        }
    }
}
